const noteForm = document.getElementById('noteForm');
const titleInput = document.getElementById('title');
const contentInput = document.getElementById('content');
const tagsInput = document.getElementById('tags');
const notesContainer = document.getElementById('notesContainer');

// Function to fetch notes
const fetchNotes = async (tags = '') => {
    const response = await fetch(`http://localhost:5000/api/notes?tags=${tags}`);
    const notes = await response.json();
    displayNotes(notes);
};

// Display notes on the page
const displayNotes = (notes) => {
    notesContainer.innerHTML = '';
    notes.forEach(note => {
        const noteElement = document.createElement('div');
        noteElement.innerHTML = `
            <h3>${note.title}</h3>
            <p>${note.content}</p>
            <p><strong>Tags:</strong> ${note.tags.join(', ')}</p>
            <button onclick="deleteNote('${note._id}')">Delete</button>
        `;
        notesContainer.appendChild(noteElement);
    });
};

// Function to handle form submission
noteForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = titleInput.value;
    const content = contentInput.value;
    const tags = tagsInput.value.split(',');

    const newNote = {
        title,
        content,
        tags
    };

    await fetch('http://localhost:5000/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newNote)
    });

    fetchNotes(); // Reload notes
});

// Function to delete a note
const deleteNote = async (id) => {
    await fetch(`http://localhost:5000/api/notes/${id}`, {
        method: 'DELETE'
    });

    fetchNotes(); // Reload notes
};

// Initial fetch of notes
fetchNotes();
