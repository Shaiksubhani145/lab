const mongoose = require('mongoose');

// Define Note Schema
const noteSchema = new mongoose.Schema({
    title: { type: String, required: true },
    content: { type: String, required: true },
    tags: [{ type: String }],
}, { timestamps: true });

// Create Note model
const Note = mongoose.model('Note', noteSchema);
module.exports = Note;
