const express = require('express');
const router = express.Router();
const { createNote, getNotes, getNoteById, updateNote, deleteNote } = require('../controllers/noteController');

// Routes for notes
router.post('/', createNote);
router.get('/', getNotes);  // GET /api/notes?tags=work,personal
router.get('/:id', getNoteById);
router.put('/:id', updateNote);
router.delete('/:id', deleteNote);

module.exports = router;
