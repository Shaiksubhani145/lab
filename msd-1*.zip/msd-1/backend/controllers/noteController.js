const Note = require('../models/noteModel');

// Create a new note
const createNote = async (req, res) => {
    const { title, content, tags } = req.body;
    try {
        const newNote = new Note({
            title,
            content,
            tags
        });
        await newNote.save();
        res.status(201).json(newNote);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get all notes or filter by tags
const getNotes = async (req, res) => {
    const { tags } = req.query;
    let filter = {};
    
    if (tags) {
        filter.tags = { $in: tags.split(',') };
    }

    try {
        const notes = await Note.find(filter);
        res.status(200).json(notes);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get a single note by ID
const getNoteById = async (req, res) => {
    try {
        const note = await Note.findById(req.params.id);
        if (!note) {
            return res.status(404).json({ message: "Note not found" });
        }
        res.status(200).json(note);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Update a note by ID
const updateNote = async (req, res) => {
    try {
        const updatedNote = await Note.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.status(200).json(updatedNote);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Delete a note by ID
const deleteNote = async (req, res) => {
    try {
        await Note.findByIdAndDelete(req.params.id);
        res.status(200).json({ message: "Note deleted successfully" });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

module.exports = { createNote, getNotes, getNoteById, updateNote, deleteNote };
